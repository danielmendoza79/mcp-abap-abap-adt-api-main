import { McpError, ErrorCode, makeAdtRequest, return_error, return_text_response, getBaseUrl } from '../lib/utils';
import convert from 'xml-js';

export async function handleGetPackage(args: any) {
    try {
        if (!args?.package_name) {
            throw new McpError(ErrorCode.InvalidParams, 'Package name is required');
        }

        const nodeContentsUrl = `${await getBaseUrl()}/sap/bc/adt/repository/nodestructure`;
        const encodedPackageName = encodeURIComponent(args.package_name);
        const nodeContentsParams = {
            parent_type: "DEVC/K",
            parent_name: encodedPackageName,
            withShortDescriptions: true
        };

        const package_structure_response = await makeAdtRequest(nodeContentsUrl, 'POST', 30000, undefined, nodeContentsParams);
        const result = convert.xml2js(package_structure_response.data, {compact: true});
        
        const nodes = result["asx:abap"]?.["asx:values"]?.DATA?.TREE_CONTENT?.SEU_ADT_REPOSITORY_OBJ_NODE || [];
        const extractedData = (Array.isArray(nodes) ? nodes : [nodes]).filter(node => 
            node.OBJECT_NAME?._text && node.OBJECT_URI?._text
        ).map(node => ({
            OBJECT_TYPE: node.OBJECT_TYPE._text,
            OBJECT_NAME: node.OBJECT_NAME._text,
            OBJECT_DESCRIPTION: node.DESCRIPTION?._text,
            OBJECT_URI: node.OBJECT_URI._text
        }));

        // Keep the legacy compact JSON for small results, but route it through
        // the same validation and UTF-8 byte cap as every other textual tool.
        return return_text_response(extractedData, args);

    } catch (error) {
        return return_error(error);
    }
}
